package com.example.eegdashboard

import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {

    private lateinit var chartImage: ImageView
    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private var scaleFactor = 1.0f

    private val chartNames = listOf(
        "Delta",
        "Theta",
        "Alpha",
        "Beta",
        "Gamma"
    )

    private val charts = listOf(
        R.drawable.delta_chart,
        R.drawable.theta_chart,
        R.drawable.alpha_chart,
        R.drawable.beta_chart,
        R.drawable.gamma_chart
    )

    private val chartInsights = listOf(
        "Delta Insight: Delta waves represent deep rest and recovery. If the during bars are higher than before, it suggests the subject reached a deeper relaxed state during meditation.",

        "Theta Insight: Theta waves are linked with calmness, creativity, and meditative focus. Higher during values suggest better relaxation and mental calm during the session.",

        "Alpha Insight: Alpha waves show relaxed awareness. A rise during meditation usually indicates that the subject became calmer while still remaining awake and aware.",

        "Beta Insight: Beta waves are connected with active thinking and stress. Lower during values are generally positive because they suggest reduced mental activity and lower stress.",

        "Gamma Insight: Gamma waves relate to high-level thinking and cognitive load. If during values decrease, it may suggest less overthinking and reduced mental processing during meditation."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val spinner = findViewById<Spinner>(R.id.adminSubjectSpinner)
        chartImage = findViewById(R.id.chartImage)
        val insightText = findViewById<TextView>(R.id.chartInsightText)

        setupZoom()

        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            chartNames
        ) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getView(position, convertView, parent) as TextView
                view.text = chartNames[position]
                view.setTextColor(Color.WHITE)
                view.setBackgroundColor(Color.rgb(31, 31, 31))
                view.textSize = 17f
                view.setPadding(24, 20, 24, 20)
                return view
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getDropDownView(position, convertView, parent) as TextView
                view.text = chartNames[position]
                view.setTextColor(Color.WHITE)
                view.setBackgroundColor(Color.rgb(31, 31, 31))
                view.textSize = 18f
                view.setPadding(28, 30, 28, 30)
                return view
            }
        }

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                chartImage.setImageResource(charts[position])
                insightText.text = chartInsights[position]

                chartImage.scaleX = 1f
                chartImage.scaleY = 1f
                scaleFactor = 1f
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupZoom() {
        scaleGestureDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    scaleFactor *= detector.scaleFactor
                    scaleFactor = scaleFactor.coerceIn(1.0f, 5.0f)

                    chartImage.scaleX = scaleFactor
                    chartImage.scaleY = scaleFactor

                    return true
                }
            }
        )

        chartImage.setOnTouchListener { _, event: MotionEvent ->
            scaleGestureDetector.onTouchEvent(event)
            true
        }
    }
}