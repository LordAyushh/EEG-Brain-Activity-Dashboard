package com.example.eegdashboard

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray

data class EEGEntry(
    val before: Map<String, Int>,
    val during: Map<String, Int>
)

class MainActivity : AppCompatActivity() {

    private val meterViews = mutableListOf<SemiCircleMeterView>()
    private lateinit var dataset: List<EEGEntry>

    private val beforeColors = mapOf(
        "Delta" to Color.rgb(120, 160, 210),
        "Theta" to Color.rgb(150, 135, 220),
        "Alpha" to Color.rgb(90, 180, 150),
        "Beta" to Color.rgb(80, 150, 220),
        "Gamma" to Color.rgb(220, 140, 120)
    )

    private val duringColors = mapOf(
        "Delta" to Color.rgb(190, 220, 255),
        "Theta" to Color.rgb(210, 200, 255),
        "Alpha" to Color.rgb(160, 245, 210),
        "Beta" to Color.rgb(140, 205, 255),
        "Gamma" to Color.rgb(255, 205, 190)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataset = loadDatasetFromJson()
        setupSpinner()
        setupDoubleTapReplay()
        setupAdminButton()

        findViewById<ImageView>(R.id.aboutBtn).setOnClickListener {
            showAboutDialog()
        }
    }

    private fun setupAdminButton() {
        findViewById<Button>(R.id.adminBtn).setOnClickListener {
            startActivity(Intent(this, AdminActivity::class.java))
        }
    }

    private fun loadDatasetFromJson(): List<EEGEntry> {
        val jsonText = resources.openRawResource(R.raw.eeg_dataset)
            .bufferedReader()
            .use { it.readText() }

        val array = JSONArray(jsonText)
        val list = mutableListOf<EEGEntry>()

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val beforeObj = obj.getJSONObject("before")
            val duringObj = obj.getJSONObject("during")

            val beforeMap = mapOf(
                "Delta" to beforeObj.getInt("Delta"),
                "Theta" to beforeObj.getInt("Theta"),
                "Alpha" to beforeObj.getInt("Alpha"),
                "Beta" to beforeObj.getInt("Beta"),
                "Gamma" to beforeObj.getInt("Gamma")
            )

            val duringMap = mapOf(
                "Delta" to duringObj.getInt("Delta"),
                "Theta" to duringObj.getInt("Theta"),
                "Alpha" to duringObj.getInt("Alpha"),
                "Beta" to duringObj.getInt("Beta"),
                "Gamma" to duringObj.getInt("Gamma")
            )

            list.add(EEGEntry(beforeMap, duringMap))
        }

        return list
    }

    private fun setupSpinner() {
        val spinner = findViewById<Spinner>(R.id.eegSpinner)
        val subjectNames = dataset.indices.map { "Subject ${it + 1}" }

        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            subjectNames
        ) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getView(position, convertView, parent) as TextView
                view.text = subjectNames[position]
                view.setTextColor(Color.WHITE)
                view.setBackgroundColor(Color.rgb(31, 31, 31))
                view.textSize = 16f
                view.setPadding(22, 18, 22, 18)
                return view
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getDropDownView(position, convertView, parent) as TextView
                view.text = subjectNames[position]
                view.setTextColor(Color.WHITE)
                view.setBackgroundColor(Color.rgb(31, 31, 31))
                view.textSize = 17f
                view.setPadding(26, 26, 26, 26)
                return view
            }
        }

        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                showEntry(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupDoubleTapReplay() {
        val root = findViewById<View>(R.id.waveContainer)

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                meterViews.forEach { it.replayAnimation() }
                return true
            }
        })

        root.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            true
        }
    }

    private fun showEntry(index: Int) {
        val entry = dataset[index]

        val container = findViewById<LinearLayout>(R.id.waveContainer)
        container.removeAllViews()
        meterViews.clear()

        val waves = listOf("Delta", "Theta", "Alpha", "Beta", "Gamma")

        waves.forEach { wave ->
            val before = entry.before[wave] ?: 0
            val during = entry.during[wave] ?: 0
            val beforeColor = beforeColors[wave] ?: Color.GRAY
            val duringColor = duringColors[wave] ?: Color.WHITE

            container.addView(createWaveCard(wave, before, during, beforeColor, duringColor))
        }

        findViewById<TextView>(R.id.finalInsightText).apply {
            text = createOverallInsight(index, entry)
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.card_bg)
        }
    }

    private fun createWaveCard(
        wave: String,
        before: Int,
        during: Int,
        beforeColor: Int,
        duringColor: Int
    ): LinearLayout {

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(20, 20, 20, 20)
        card.setBackgroundResource(R.drawable.card_bg)

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 0, 0, 16)
        card.layoutParams = params

        val title = TextView(this)
        title.text = wave.uppercase()
        title.setTextColor(duringColor)
        title.textSize = 18f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        card.addView(title)

        val meter = SemiCircleMeterView(this, null)
        meter.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            120
        )
        meter.setMeter(before, during, beforeColor, duringColor)
        meterViews.add(meter)
        card.addView(meter)

        val legend = TextView(this)
        legend.text = "Outer arc: Before   •   Inner arc: During"
        legend.setTextColor(Color.LTGRAY)
        legend.textSize = 12f
        legend.gravity = Gravity.CENTER
        card.addView(legend)

        val values = TextView(this)
        values.text = "Before: $before%   |   During: $during%"
        values.setTextColor(Color.WHITE)
        values.textSize = 14f
        values.setPadding(0, 10, 0, 10)
        card.addView(values)

        val insight = TextView(this)
        insight.text = getMetricInsight(wave, before, during)
        insight.setTextColor(Color.rgb(210, 210, 210))
        insight.textSize = 13f
        insight.setPadding(0, 8, 0, 0)
        card.addView(insight)

        return card
    }

    private fun getMetricInsight(wave: String, before: Int, during: Int): String {
        val diff = during - before

        return when (wave) {
            "Delta" -> if (diff > 0)
                "Insight: Delta increased by $diff%, showing deeper relaxation and reduced mental activity."
            else
                "Insight: Delta decreased by ${-diff}%, suggesting deep relaxation was not strongly reached."

            "Theta" -> if (diff > 0)
                "Insight: Theta increased by $diff%, indicating better calmness and meditative focus."
            else
                "Insight: Theta decreased by ${-diff}%, meaning calm focus reduced during the session."

            "Alpha" -> if (diff > 0)
                "Insight: Alpha increased by $diff%, which is a positive sign of relaxed awareness."
            else
                "Insight: Alpha decreased by ${-diff}%, so relaxed awareness did not improve much."

            "Beta" -> if (diff < 0)
                "Insight: Beta decreased by ${-diff}%, suggesting stress and active thinking reduced."
            else
                "Insight: Beta increased by $diff%, meaning the mind stayed active during meditation."

            "Gamma" -> if (diff < 0)
                "Insight: Gamma decreased by ${-diff}%, showing reduced cognitive load."
            else
                "Insight: Gamma increased by $diff%, indicating stronger high-level mental processing."

            else -> "Insight unavailable."
        }
    }

    private fun createOverallInsight(index: Int, entry: EEGEntry): String {
        val alphaBefore = entry.before["Alpha"] ?: 0
        val alphaDuring = entry.during["Alpha"] ?: 0
        val betaBefore = entry.before["Beta"] ?: 0
        val betaDuring = entry.during["Beta"] ?: 0
        val thetaBefore = entry.before["Theta"] ?: 0
        val thetaDuring = entry.during["Theta"] ?: 0

        return if (alphaDuring > alphaBefore && betaDuring < betaBefore) {
            "Subject ${index + 1} Overall Insight: Meditation response is positive. Alpha increased and Beta decreased, which suggests improved calm focus."
        } else if (thetaDuring > thetaBefore) {
            "Subject ${index + 1} Overall Insight: Theta increased, showing better meditative calmness, but the overall relaxation response is mixed."
        } else {
            "Subject ${index + 1} Overall Insight: EEG response is mixed. Longer or repeated meditation may improve relaxation balance."
        }
    }

    private fun showAboutDialog() {
        val message = """
Brain waves represent different states of the mind:

Delta
- very slow waves
- seen in deep sleep
- linked with deep rest and recovery

Theta
- linked with relaxation and meditation
- appears during light sleep or deep calm
- helps creativity and emotional processing

Alpha
- state of relaxed awareness
- seen when the mind is calm but awake
- important for meditation and stress reduction

Beta
- associated with active thinking and focus
- high levels may indicate stress or anxiety
- normal during problem solving

Gamma
- linked with high level thinking and awareness
- involved in memory and learning
- too high may indicate overthinking
""".trimIndent()

        AlertDialog.Builder(this)
            .setTitle("About EEG Waves")
            .setMessage(message)
            .setPositiveButton("Close", null)
            .show()
    }
}