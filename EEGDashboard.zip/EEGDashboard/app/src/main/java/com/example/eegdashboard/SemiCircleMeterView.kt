package com.example.eegdashboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

class SemiCircleMeterView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private var beforeValue = 0
    private var duringValue = 0

    private var animatedBefore = 0f
    private var animatedDuring = 0f

    private var beforeColor = Color.GRAY
    private var duringColor = Color.CYAN

    private var animator: ValueAnimator? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(55, 55, 55)
        strokeWidth = 20f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val beforePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 18f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val duringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setMeter(before: Int, during: Int, beforeColor: Int, duringColor: Int) {
        this.beforeValue = before
        this.duringValue = during
        this.beforeColor = beforeColor
        this.duringColor = duringColor

        replayAnimation()
    }

    fun replayAnimation() {
        animator?.cancel()

        animatedBefore = 0f
        animatedDuring = 0f

        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            interpolator = DecelerateInterpolator()

            addUpdateListener {
                val progress = it.animatedValue as Float

                animatedBefore = beforeValue * progress
                animatedDuring = duringValue * progress

                invalidate()
            }

            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        beforePaint.color = beforeColor
        duringPaint.color = duringColor

        val rect = RectF(35f, 25f, width - 35f, height * 2f - 25f)

        canvas.drawArc(rect, 180f, 180f, false, bgPaint)

        canvas.drawArc(
            rect,
            180f,
            180f * (animatedBefore / 100f),
            false,
            beforePaint
        )

        val innerRect = RectF(55f, 45f, width - 55f, height * 2f - 45f)

        canvas.drawArc(
            innerRect,
            180f,
            180f * (animatedDuring / 100f),
            false,
            duringPaint
        )

        canvas.drawText(
            "${animatedDuring.toInt()}%",
            width / 2f,
            height - 10f,
            textPaint
        )
    }
}